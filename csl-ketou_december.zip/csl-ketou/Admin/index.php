<?php
    header('Location: ./csl-backend/index');
?>