<?php
    header('Location: ./index');
?>